import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
import { AppComponent } from './app.component';
import { DragdropComponent } from './modules/dragdrop/dragdrop.component';
import {DragDropModule} from '@angular/cdk/drag-drop';

const routes: Routes = [
  { path: '', component: DragdropComponent },
  { path: 'drag_drop', component: DragdropComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    DragdropComponent
  ],
  imports: [
    BrowserModule,
    DragDropModule,
    RouterModule.forRoot(routes,
      {
        preloadingStrategy: PreloadAllModules
      }
    ),    
  ],
  providers: [],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],  
  bootstrap: [AppComponent],
  exports: [
    RouterModule]
})
export class AppModule { }
